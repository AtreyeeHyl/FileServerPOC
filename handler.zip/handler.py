import pymysql
import json
from datetime import datetime

# Lambda Permissions:
# AWSLambdaVPCAccessExecutionRole
 
#Configuration Values
endpoint = 'file-server-db.cx644oceaozv.eu-north-1.rds.amazonaws.com'
username = 'admin'
password = '12345678'
database_name = 'fileServerDB'
 
#Connection
connection = pymysql.connect(
    host=endpoint,
    user=username,
    password=password,  
    database=database_name 
)


# Function to insert metadata into the database
def insert_metadata(file_name, file_type, file_path, file_size, upload_date):
    try:
        with connection.cursor() as cursor:
            # SQL query to insert the file metadata into the database
            query = """
                INSERT INTO FileMetadata (FileName, FileType, FilePath, FileSize, UploadDate)
                VALUES (%s, %s, %s, %s, %s)
            """
            # Execute the query with the provided values
            cursor.execute(query, (file_name, file_type, file_path, file_size, upload_date))
            connection.commit()  # Commit the transaction
            print("File metadata inserted into RDS successfully.")
    except Exception as e:
        print(f"Error inserting metadata into RDS: {e}")
        

 
def lambda_handler(event, context):
    try:
        print("Received event:", json.dumps(event))  # For debugging: print the entire event
        
        for record in event['Records']:
            sns_message = json.loads(record['Sns']['Message'])  # Parse the SNS message
            
            print("Parsed SNS message:", sns_message)
            
            # Extracting file metadata from the SNS message
            for sns_record in sns_message.get('Records', []):
                s3_object = sns_record.get('s3', {}).get('object', {})
                
                file_name = s3_object.get('key')
                file_size = s3_object.get('size')
                upload_date = sns_record.get('eventTime')  # Use eventTime as the upload date
                file_type = file_name.split('.')[-1]  # Using file extension as file type (adjust as necessary)
                file_key = s3_object.get('key')
                
                # Check if all required fields are present
                if not all([file_name, file_size, upload_date, file_type, file_key]):
                    print("Missing required metadata fields in SNS message.")
                    return {
                        'statusCode': 400,
                        'body': json.dumps('Missing required metadata fields in SNS message.')
                    }
            
                # Convert upload date to datetime object if necessary
                upload_date = datetime.strptime(upload_date, "%Y-%m-%dT%H:%M:%S.%fZ")
            
                # Insert metadata into RDS
                insert_metadata(file_name, file_type, file_key, file_size, upload_date)
            
        return {
            'statusCode': 200,
            'body': json.dumps('File metadata processed successfully.')
        }
    
    except Exception as e:
        print(f"Error processing the event: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error processing the event: {e}")
        }
    

